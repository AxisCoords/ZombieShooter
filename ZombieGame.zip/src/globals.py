WIDTH, HEIGHT = 500, 500
TITLE: str = "ZOMBIE SHOOTER"

SPRITE_SIZE: int = 3
SPRITE_IMAGE = "assets/atlas.png"

isDebugVisible: bool = False
gameOver: bool = False
