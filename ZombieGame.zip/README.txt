Name: Behrooz Jamdar
Neptun Code: OGQEAS
Date: 5/11/2025

---INSTRUCTIONS---
In order to run the program, you need to have "pygame-ce" installed.
Please run the following command in your terminal to install:

    pip install pygame-ce
    or
    pip3 install pygame-ce
    or
    python -m pip install pygame-ce

After installing pygame-ce, in order to run the program please open your terminal in the root directory and run the following command:
    Windows:
        python.exe .\main.py
        or
        python .\main.py
    Linux:
        python3 main.py